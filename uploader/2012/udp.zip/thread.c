#include <conio.h>
#include <stdio.h>
#include <winsock2.h> 
#include <windows.h>
#pragma comment (lib,"ws2_32.lib")

  #define LOCAL_PORT 44065
  #define LOCAL_ADDR "192.168.1.3"
  #define DEST_PORT 4064
  #define DEST_ADDR "192.168.10.1"

unsigned char FLAP[] = "AT_AIR_TRACER";
unsigned char BUE[] = "BUE_BUE";

BOOL hardstop;
BOOL softstop;
BOOL lockcode;
BOOL retcode;
BOOL endsignal;
BOOL end;

unsigned long LogMessage(char * sMessage);

unsigned long WINAPI ThreadProc(LPVOID lpParameter){
    SOCKET my_sock;
    SOCKADDR_IN local_addr;
    int local_addr_size;
    int bsize;
    int i;
    char buff[1024];
    char z[200];
    unsigned long source;
    unsigned long dest;
    unsigned char color;
    unsigned char tmp;

    my_sock=socket(AF_INET, SOCK_DGRAM, 0);
    if (my_sock==INVALID_SOCKET)
    {
        printf("socket() error: %d\n",WSAGetLastError());
        endsignal = 1;
        return 0;
    }

    local_addr.sin_family=AF_INET;
    local_addr.sin_addr.s_addr=INADDR_ANY;
    local_addr.sin_port=htons(LOCAL_PORT);
    memset(&(local_addr.sin_zero), '\0', 8);

    if (bind(my_sock,(SOCKADDR*) &local_addr, sizeof(local_addr)))
    {
      printf("bind error: %d\n",WSAGetLastError());
      closesocket(my_sock);
        endsignal = 1;
        return 0;
    }

    local_addr.sin_addr.s_addr=inet_addr(DEST_ADDR);
    local_addr.sin_port=htons(DEST_PORT);

    sendto(my_sock, FLAP, sizeof(FLAP), 0, (SOCKADDR*)&local_addr, sizeof(local_addr));

    do {
         local_addr_size = sizeof(local_addr);
         bsize=recvfrom(my_sock,&buff[0],sizeof(buff)-1,0,(SOCKADDR*) &local_addr, &local_addr_size);
         if (bsize==SOCKET_ERROR){
             printf("local recvfrom() error: %d\n", WSAGetLastError());
          }
         else{

            if(bsize == 2){
                if((buff[0] == 0x4F)&&(buff[1] == 0x4B)) {
                    printf("\n [+] OK !\n");
                    LogMessage("recive OK");
                }
            }

            if(bsize == 34){
                if((buff[0] == 0x00)&&(buff[1] == 0x18)&&(buff[4] == 0x0B)){
                    source = 0;
                    source <<= 8;
                    tmp = buff[16];
                    source += tmp;
                    source <<=8;
                    tmp = buff[17];
                    source += tmp;
                    source <<= 8;
                    tmp = buff[18];
                    source += tmp;
                    dest  = 0;
                    dest  <<= 8;
                    tmp = buff[13];
                    dest  += tmp;
                    dest  <<=8;
                    tmp = buff[14];
                    dest  += tmp;
                    dest  <<= 8;
                    tmp = buff[15];
                    dest  += tmp;
                    color = 0;
                    tmp = buff[28];
                    tmp >>= 4;
                    color = tmp;
                    if((buff[12] == 0x08)&&(buff[10] == 0x00)){
                        lockcode = 1;
                        i = 0;
                        i+=sprintf(z+i,"ALL dest: %d source: %d color: %d", dest, source,  color );
                        LogMessage(z);
                        lockcode = 0;
                    }

                    if((buff[12] == 0x00)&&(buff[10] == 0x03)) {
                        lockcode = 1;
                        i = 0;
                        i+=sprintf(z+i,"CALL dest: %d source: %d color: %d", dest, source,  color );
                        LogMessage(z);
                        lockcode = 0;
                    }

                    if((buff[12] == 0x00)&&(buff[10] == 0x00)) {
                        lockcode = 1;
                        i = 0;
                        i+=sprintf(z+i,"GROUP  dest: %d source: %d color: %d", dest, source,  color );
                        LogMessage(z);
                        lockcode = 0;
                    }
                    if((buff[12] == 0x08)&&(buff[10] == 0x00)) printf("all  dest: %d source: %d color: %d \n",dest, source, color );
                    if((buff[12] == 0x00)&&(buff[10] == 0x03)) printf("call  dest: %d source: %d color: %d \n",dest, source, color );
                    if((buff[12] == 0x00)&&(buff[10] == 0x00)) printf("group  dest: %d source: %d color: %d \n",dest, source, color );
                }
            }
         }
    } while(!endsignal);
    closesocket(my_sock);
    printf("\nThreadProc exit !\n");
    endsignal = 1;
    return 0;
} 



unsigned long SoftStop(HANDLE  hThread){
    SOCKET my_sock;
    SOCKADDR_IN local_addr;
    unsigned char i;
    unsigned long lpExitCode;

    my_sock=socket(AF_INET, SOCK_DGRAM, 0);
    if (my_sock==INVALID_SOCKET)
    {
        printf("socket() error: %d\n",WSAGetLastError());
        endsignal = 1;
        return 1;
    }

    local_addr.sin_family=AF_INET;
    local_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    local_addr.sin_port=htons(LOCAL_PORT);
    memset(&(local_addr.sin_zero), '\0', 8);

    printf("\n\n set end flag, resive packet to exit \n\n");

    endsignal = 1;
    softstop  = 0;

    for(i = 20; i > 0; i--) {
    printf("Softstop count: %d \r", i );
        sendto(my_sock, BUE, sizeof(BUE), 0, (SOCKADDR*)&local_addr, sizeof(local_addr));
        if(GetExitCodeThread(hThread, &lpExitCode)){
            if(0 == lpExitCode) {
                closesocket(my_sock);
                CloseHandle(hThread);
                printf("\nThread halted\n");
                LogMessage("Softstop ok, Thread halted");
                return 1;
            }
        }
        Sleep(1000);
    }
    closesocket(my_sock);
    printf("Softstop error, send hardstop \n");
    LogMessage("Softstop error");
    return 0;
}


unsigned long HardStop(HANDLE   hThread){
    unsigned long lpExitCode;
    unsigned char i;
    endsignal = 1;
    printf("\nHARDSTOP!!! \n\n");
    for(i = 20; i > 0; i--) {
        printf("Hardstop count: %d \r", i );
        if( !lockcode ){
            TerminateThread ( hThread, 0 );
            Sleep(1000);
            if(GetExitCodeThread(hThread, &lpExitCode)){
                if(0 == lpExitCode) {
                    printf("\nThread terminated, lockcode off\n");
                    LogMessage("Thread terminated, lockcode off ");
                    CloseHandle(hThread);
                    endsignal = 0;
                    return 1;
                }
            }
        }
        Sleep(1000);
    }
    printf("\nThread terminated! lockcode ON !!!\n");
    LogMessage("Thread terminated! lockcode ON !!!");
    TerminateThread ( hThread, 0 );
    CloseHandle(hThread);
    endsignal = 0;
    return 1;
}

unsigned long WINAPI UserProc(LPVOID lpParam){ 
    unsigned char ch;
    while (1) {
        ch = getch();
        if(ch=='q'||ch=='Q') {
            softstop = 1;
        }
        if(ch=='s'||ch=='S') {
            softstop = 1;
            //break;
        }
        if(ch=='h'||ch=='H') {
            hardstop = 1;
            //break;
        }
        if(ch=='r'||ch=='R') {
        }
        if(ch=='y'||ch=='Y') {
        }
        if(ch=='n'||ch=='N') {
        }
        if(retcode) { 
        end = 1;
        return 0;
        }
    }
    end =1;
    return 0;
}

void Banner (void){
printf(" press q key to exit \r");
}

int main(int argc,char ** argv) 
{
    WSADATA WSAData;
    HANDLE   hThread;
    unsigned long id;

    hardstop = 0;
    softstop = 0;
    lockcode = 0;
    retcode = 0;
    endsignal = 0;
    end = 0;

    if (WSAStartup(MAKEWORD(2,0),&WSAData)!=0){
        printf("WSAStartup error.Error:%d\n",WSAGetLastError());
        return 0;
    }

    LogMessage("Starting");

    hThread = CreateThread(0,0,&UserProc,"",0,&id);
    CloseHandle(hThread);

    hThread=CreateThread(0,0,&ThreadProc,"",0,&id); 

    do{
        if(softstop) retcode = SoftStop(hThread);
        if(hardstop) retcode = HardStop(hThread);
        Sleep(500);
    } while(!retcode);

    WSACleanup();

    printf("\n\nprogram stopped, press any key to exit \n");
    LogMessage("Program stopped");
    while(!end);
    return 0;
}


unsigned long LogMessage(char * sMessage)
{
	FILE * ffLog;
	SYSTEMTIME st1;

	//if (iLogFile==0) return 0;//skip file

	ffLog = fopen("msgack.log","at");

	if (ffLog==NULL) return 1; //error
	GetLocalTime(&st1);
	fprintf(ffLog,"%02i.%02i.%04i %02i:%02i:%02i.%03i ",st1.wDay,st1.wMonth,st1.wYear,st1.wHour,st1.wMinute,st1.wSecond,st1.wMilliseconds);
	fprintf(ffLog,"%s\n",sMessage);

	fclose(ffLog);
	return 0;//OK
}



// BOOL SetThreadPriority(HANDLE hThread, int nPriority);
// BOOL GetExitCodeThread(HANDLE hThread, LPDWORD lpExitCode);
// BOOL CloseHandle(HANDLE hObject);




